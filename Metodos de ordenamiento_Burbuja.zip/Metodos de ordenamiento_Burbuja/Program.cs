﻿using System;
using System.Numerics;
using System.Runtime.CompilerServices;

class Program
{
    static void Main(string[] args)
    {
        int n;
        Console.Write("Please enter the number of elements to sort : ");
        n = int.Parse(Console.ReadLine());

        int[] vector = new int[n];
        for (int i = 0; i < n; i++)
        {
            Console.Write("Enter number {0}: ", i + 1);
            vector[i] = int.Parse(Console.ReadLine());
        }

        presenta_datos();

     
        ordena_burbuja(n);

        void presenta_datos()
        {
            Console.Write("\n");
            
            int h = 0;
            Console.Write("********************************");
            Console.Write("|");
            for (h = 0; h < n; h++)
            {
                Console.Write("{0}|", vector[h]);
            }
            Console.Write("********************************\n");
        }
        Console.WriteLine("\n El programa ha terminado.");


        void ordena_burbuja(int tamaño) 
        {
            int posicion = 0;
            int parcial = 0;
            int evalua = 0;
            while (posicion < tamaño)
            {
                evalua = posicion + 1;
                while (evalua < tamaño)
                   
                {
                    if (vector[posicion] > vector[evalua])
                    {
                        
                        Console.Write("\"Replace the {0} located at position {1} with the {2} located at position {3} \n", vector[posicion], posicion, vector[evalua],evalua);             
                        parcial = vector[evalua];
                        vector[evalua] = vector[posicion];
                        vector[posicion] = parcial;
                        presenta_datos();
                    }
                    evalua ++;
                }
                posicion ++;
                
            }
        }

    }

    
   
}

